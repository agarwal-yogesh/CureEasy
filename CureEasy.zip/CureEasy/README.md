# CureEasy

![GitHub Logo](https://github.com/akshat220/CureEasy/blob/master/app/src/main/res/drawable/ce.png)
![GitHub Logo](https://github.com/akshat220/CureEasy/blob/master/app/src/main/res/drawable/al.png)
